<?php include '../../includes/header.php'; ?>

<div class="container mt-4">
  <h2>Misiones Disponibles</h2>
  <ul class="list-group">
    <li class="list-group-item">Misión 1: Completar actividad inicial</li>
    <li class="list-group-item">Misión 2: Subir entregas antes de fecha límite</li>
  </ul>
</div>

<?php include '../../includes/footer.php'; ?>
