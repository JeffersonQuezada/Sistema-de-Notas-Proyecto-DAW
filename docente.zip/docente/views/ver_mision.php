<?php include '../../includes/header.php'; ?>

<div class="container mt-4">
  <h2>Detalle de Misión</h2>
  <p>Descripción detallada de la misión, requisitos y fecha límite.</p>
</div>

<?php include '../../includes/footer.php'; ?>
