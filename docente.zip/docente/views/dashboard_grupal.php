<?php include '../../includes/header.php'; ?>

<div class="container mt-4">
  <h2>Dashboard Grupal</h2>
  <p>Listado de grupos y desempeño general.</p>
</div>

<?php include '../../includes/footer.php'; ?>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Aquí puedes agregar cualquier script adicional que necesites
  });   