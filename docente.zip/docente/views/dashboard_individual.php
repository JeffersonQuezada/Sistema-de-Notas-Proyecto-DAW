<?php include '../../includes/header.php'; ?>

<div class="container mt-4">
  <h2>Dashboard Individual</h2>
  <p>Datos detallados del estudiante seleccionado.</p>
</div>

<?php include '../../includes/footer.php'; ?>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Aquí puedes agregar cualquier script adicional que necesites
  });