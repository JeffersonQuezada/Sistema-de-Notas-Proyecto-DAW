<?php
require_once '../models/ActividadModel.php';
require_once '../models/CursoModel.php';
session_start();

// Verificar sesión
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

$id_docente = $_SESSION['id_usuario'];

$cursoModel = new CursoModel();
$actividadModel = new ActividadModel();

// Obtener cursos del docente
$cursos = $cursoModel->listarCursosPorDocente($id_docente);

// Obtener actividades por curso
$actividades_por_curso = [];
foreach ($cursos as $curso) {
    $actividades_por_curso[$curso['id_curso']] = [
        'curso' => $curso,
        'actividades' => $actividadModel->listarActividadesPorCurso($curso['id_curso'])
    ];
}

// Mensajes
$mensaje = '';
$tipo_mensaje = '';

if (isset($_GET['success'])) {
    $tipo_mensaje = 'success';
    $mensaje = isset($_GET['msg']) ? $_GET['msg'] : 'Operación realizada exitosamente.';
}

if (isset($_GET['error'])) {
    $tipo_mensaje = 'danger';
    $mensaje = isset($_GET['msg']) ? $_GET['msg'] : 'Ha ocurrido un error.';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Actividades - Sistema Académico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #64748b;
            --success-color: #059669;
            --danger-color: #dc2626;
            --warning-color: #d97706;
            --info-color: #0891b2;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .main-container {
            padding: 2rem 0;
            min-height: 100vh;
        }

        .page-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .stats-card {
            background: linear-gradient(135deg, var(--info-color), #06b6d4);
            color: white;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 5px 15px rgba(8, 145, 178, 0.3);
        }

        .curso-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .curso-card:hover {
            transform: translateY(-2px);
        }

        .curso-header {
            background: linear-gradient(135deg, var(--primary-color), #3b82f6);
            color: white;
            padding: 1.5rem;
            position: relative;
            overflow: hidden;
        }

        .curso-header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 200%;
            background: rgba(255, 255, 255, 0.1);
            transform: rotate(45deg);
            transition: all 0.3s ease;
        }

        .curso-header:hover::before {
            right: -40%;
        }

        .curso-title {
            margin: 0;
            font-size: 1.25rem;
            font-weight: 600;
            position: relative;
            z-index: 1;
        }

        .curso-code {
            opacity: 0.9;
            font-size: 0.9rem;
            position: relative;
            z-index: 1;
        }

        .curso-stats {
            position: relative;
            z-index: 1;
        }

        .actividad-item {
            border-left: 4px solid var(--primary-color);
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
            margin-bottom: 1rem;
            border-radius: 0 15px 15px 0;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .actividad-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: var(--primary-color);
            transition: width 0.3s ease;
        }

        .actividad-item:hover {
            transform: translateX(5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        .actividad-item:hover::before {
            width: 8px;
        }

        .actividad-item.vencida {
            border-left-color: var(--danger-color);
            background: linear-gradient(135deg, #fef2f2, #fee2e2);
        }

        .actividad-item.vencida::before {
            background: var(--danger-color);
        }

        .actividad-item.proxima {
            border-left-color: var(--warning-color);
            background: linear-gradient(135deg, #fffbeb, #fef3c7);
        }

        .actividad-item.proxima::before {
            background: var(--warning-color);
        }

        .actividad-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 1rem;
        }

        .actividad-title {
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
        }

        .actividad-descripcion {
            color: #4a5568;
            margin-bottom: 1rem;
            line-height: 1.5;
        }

        .actividad-meta {
            font-size: 0.875rem;
            color: var(--secondary-color);
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            align-items: center;
        }

        .badge-tipo {
            font-size: 0.75rem;
            padding: 0.4rem 0.8rem;
            border-radius: 20px;
            font-weight: 500;
        }

        .fecha-limite {
            padding: 0.3rem 0.8rem;
            border-radius: 15px;
            font-weight: 600;
            font-size: 0.8rem;
        }

        .fecha-limite.vencida {
            background: rgba(220, 38, 38, 0.1);
            color: var(--danger-color);
        }

        .fecha-limite.proxima {
            background: rgba(217, 119, 6, 0.1);
            color: var(--warning-color);
        }

        .fecha-limite.lejana {
            background: rgba(5, 150, 105, 0.1);
            color: var(--success-color);
        }

        .btn-action {
            width: 35px;
            height: 35px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .btn-action:hover {
            transform: translateY(-2px);
        }

        .btn-floating {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--success-color), #10b981);
            color: white;
            border: none;
            box-shadow: 0 10px 25px rgba(5, 150, 105, 0.4);
            transition: all 0.3s ease;
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-floating:hover {
            transform: translateY(-5px) rotate(90deg);
            box-shadow: 0 15px 35px rgba(5, 150, 105, 0.6);
            color: white;
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            color: var(--secondary-color);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        .empty-state h5 {
            color: var(--secondary-color);
            margin-bottom: 1rem;
        }

        .filter-tabs {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 1rem;
            margin-bottom: 2rem;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .nav-pills .nav-link {
            border-radius: 10px;
            color: var(--secondary-color);
            transition: all 0.3s ease;
        }

        .nav-pills .nav-link.active {
            background: var(--primary-color);
            color: white;
        }

        .curso-collapse {
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .curso-collapse:hover {
            opacity: 0.8;
        }

        .collapse-icon {
            transition: transform 0.3s ease;
        }

        .collapsed .collapse-icon {
            transform: rotate(-90deg);
        }

        @media (max-width: 768px) {
            .main-container {
                padding: 1rem;
            }
            
            .page-header {
                padding: 1.5rem;
            }
            
            .actividad-header {
                flex-direction: column;
                gap: 0.5rem;
            }

            .actividad-meta {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
            }

            .btn-floating {
                bottom: 1rem;
                right: 1rem;
                width: 50px;
                height: 50px;
            }
        }

        .loading-spinner {
            display: none;
            text-align: center;
            padding: 2rem;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <div class="container">
            <!-- Header -->
            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h1 class="h2 mb-2">
                            <i class="fas fa-tasks me-3"></i>
                            Mis Actividades
                        </h1>
                        <p class="text-muted mb-0">Gestiona y organiza las actividades de tus cursos</p>
                    </div>
                    <div class="col-md-4">
                        <div class="stats-card">
                            <div class="h3 mb-1"><?= count($cursos) ?></div>
                            <div>Curso(s) Asignado(s)</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Mensajes -->
            <?php if (!empty($mensaje)): ?>
                <div class="alert alert-<?= $tipo_mensaje ?> alert-dismissible fade show shadow" role="alert">
                    <i class="fas fa-<?= $tipo_mensaje === 'success' ? 'check-circle' : 'exclamation-triangle' ?> me-2"></i>
                    <?= htmlspecialchars($mensaje) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Filtros -->
            <div class="filter-tabs">
                <ul class="nav nav-pills justify-content-center" id="filtroTabs">
                    <li class="nav-item">
                        <button class="nav-link active" data-filter="todas">
                            <i class="fas fa-list me-2"></i>Todas
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" data-filter="proximas">
                            <i class="fas fa-clock me-2"></i>Próximas a vencer
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" data-filter="vencidas">
                            <i class="fas fa-exclamation-triangle me-2"></i>Vencidas
                        </button>
                    </li>
                </ul>
            </div>

            <!-- Lista de Cursos y Actividades -->
            <?php if (!empty($actividades_por_curso)): ?>
                <?php foreach ($actividades_por_curso as $curso_id => $data): ?>
                    <div class="curso-card">
                        <div class="curso-header curso-collapse" data-bs-toggle="collapse" data-bs-target="#curso<?= $curso_id ?>" role="button">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="curso-title">
                                        <i class="fas fa-chevron-down collapse-icon me-2"></i>
                                        <?= htmlspecialchars($data['curso']['nombre']) ?>
                                    </h3>
                                    <?php if (!empty($data['curso']['codigo_curso'])): ?>
                                        <div class="curso-code">
                                            <i class="fas fa-code me-1"></i>
                                            <?= htmlspecialchars($data['curso']['codigo_curso']) ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="curso-stats text-end">
                                    <div class="h4 mb-0"><?= count($data['actividades']) ?></div>
                                    <small>Actividad(es)</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="collapse show" id="curso<?= $curso_id ?>">
                            <div class="p-3">
                                <?php if (!empty($data['actividades'])): ?>
                                    <?php foreach ($data['actividades'] as $actividad): ?>
                                        <?php
                                        // Calcular días hasta la fecha límite
                                        $fecha_limite = new DateTime($actividad['fecha_limite']);
                                        $hoy = new DateTime();
                                        $diferencia = $hoy->diff($fecha_limite);
                                        $dias_restantes = $diferencia->days;
                                        
                                        $clase_fecha = 'lejana';
                                        $clase_item = '';
                                        if ($fecha_limite < $hoy) {
                                            $clase_fecha = 'vencida';
                                            $clase_item = 'vencida';
                                            $texto_fecha = 'Vencida hace ' . $dias_restantes . ' día(s)';
                                        } elseif ($dias_restantes <= 3) {
                                            $clase_fecha = 'proxima';
                                            $clase_item = 'proxima';
                                            $texto_fecha = $dias_restantes == 0 ? 'Vence hoy' : 'Vence en ' . $dias_restantes . ' día(s)';
                                        } else {
                                            $texto_fecha = 'Vence en ' . $dias_restantes . ' día(s)';
                                        }

                                        // Colores para tipos de actividad
                                        $colores_tipo = [
                                            'Tarea' => 'bg-primary',
                                            'Proyecto' => 'bg-info', 
                                            'Examen' => 'bg-danger',
                                            'Laboratorio' => 'bg-success',
                                            'Investigación' => 'bg-warning'
                                        ];
                                        $color_tipo = $colores_tipo[$actividad['tipo']] ?? 'bg-secondary';
                                        ?>
                                        
                                        <div class="actividad-item <?= $clase_item ?> p-3" data-tipo="<?= strtolower($actividad['tipo']) ?>" data-estado="<?= $clase_fecha ?>">
                                            <div class="actividad-header">
                                                <div class="flex-grow-1">
                                                    <h5 class="actividad-title">
                                                        <i class="fas fa-clipboard-list me-2"></i>
                                                        <?= htmlspecialchars($actividad['nombre']) ?>
                                                    </h5>
                                                    <p class="actividad-descripcion">
                                                        <?= htmlspecialchars(substr($actividad['descripcion'], 0, 150)) ?>
                                                        <?= strlen($actividad['descripcion']) > 150 ? '...' : '' ?>
                                                    </p>
                                                    <div class="actividad-meta">
                                                        <span class="badge <?= $color_tipo ?> badge-tipo">
                                                            <i class="fas fa-tag me-1"></i>
                                                            <?= htmlspecialchars($actividad['tipo']) ?>
                                                        </span>
                                                        <span class="fecha-limite <?= $clase_fecha ?>">
                                                            <i class="fas fa-clock me-1"></i>
                                                            <?= $texto_fecha ?>
                                                        </span>
                                                        <span class="text-muted">
                                                            <i class="fas fa-calendar me-1"></i>
                                                            <?= date('d/m/Y H:i', strtotime($actividad['fecha_limite'])) ?>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="flex-shrink-0">
                                                    <div class="btn-group-vertical" role="group">
                                                        <button type="button" 
                                                                class="btn btn-outline-primary btn-action mb-1" 
                                                                onclick="editarActividad(<?= $actividad['id_actividad'] ?>)"
                                                                title="Editar actividad">
                                                            <i class="fas fa-edit"></i>
                                                        </button>
                                                        <button type="button" 
                                                                class="btn btn-outline-info btn-action mb-1" 
                                                                onclick="verDetalles(<?= $actividad['id_actividad'] ?>)"
                                                                title="Ver detalles">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <button type="button" 
                                                                class="btn btn-outline-danger btn-action" 
                                                                onclick="eliminarActividad(<?= $actividad['id_actividad'] ?>, '<?= htmlspecialchars($actividad['nombre']) ?>')"
                                                                title="Eliminar actividad">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="empty-state">
                                        <i class="fas fa-clipboard-list"></i>
                                        <h5>No hay actividades</h5>
                                        <p class="text-muted">Aún no has creado actividades para este curso.</p>
                                        <a href="nueva_actividad.php" class="btn btn-primary">
                                            <i class="fas fa-plus me-2"></i>Crear primera actividad
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="curso-card">
                    <div class="empty-state">
                        <i class="fas fa-graduation-cap"></i>
                        <h5>No tienes cursos asignados</h5>
                        <p class="text-muted">Contacta al administrador para que te asigne cursos.</p>
                        <button class="btn btn-outline-primary" onclick="location.reload()">
                            <i class="fas fa-refresh me-2"></i>Actualizar
                        </button>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Spinner de carga -->
            <div class="loading-spinner">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Cargando...</span>
                </div>
                <p class="mt-2">Procesando...</p>
            </div>
        </div>
    </div>

    <!-- Botón flotante para nueva actividad -->
    <button class="btn-floating" onclick="window.location.href='nueva_actividad.php'" title="Nueva actividad">
        <i class="fas fa-plus fa-lg"></i>
    </button>

    <!-- Modal de confirmación para eliminar -->
    <div class="modal fade" id="modalEliminar" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">
                        <i class="fas fa-exclamation-triangle text-warning me-2"></i>
                        Confirmar eliminación
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>¿Estás seguro de que deseas eliminar la actividad <strong id="nombreActividad"></strong>?</p>
                    <div class="alert alert-warning">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Advertencia:</strong> Esta acción no se puede deshacer.
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-2"></i>Cancelar
                    </button>
                    <button type="button" class="btn btn-danger" id="btnConfirmarEliminar">
                        <i class="fas fa-trash me-2"></i>Eliminar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de detalles -->
    <div class="modal fade" id="modalDetalles" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-info-circle me-2"></i>
                        Detalles de la Actividad
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="detallesContent">
                    <!-- Contenido dinámico -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let actividadAEliminar = null;

        // Función para editar actividad
        function editarActividad(id) {
            mostrarSpinner(true);
            setTimeout(() => {
                window.location.href = `editar_actividad.php?id=${id}`;
            }, 500);
        }

        // Función para ver detalles
        function verDetalles(id) {
            // Aquí puedes hacer una llamada AJAX para obtener los detalles
            // Por ahora, simplemente mostramos un mensaje
            document.getElementById('detallesContent').innerHTML = `
                <div class="text-center">
                    <i class="fas fa-info-circle fa-3x text-info mb-3"></i>
                    <h5>Detalles de la Actividad</h5>
                    <p>Funcionalidad en desarrollo...</p>
                    <p class="text-muted">ID de Actividad: ${id}</p>
                </div>
            `;
            
            const modal = new bootstrap.Modal(document.getElementById('modalDetalles'));
            modal.show();
        }

        // Función para eliminar actividad
        function eliminarActividad(id, nombre) {
            actividadAEliminar = id;
            document.getElementById('nombreActividad').textContent = nombre;
            
            const modal = new bootstrap.Modal(document.getElementById('modalEliminar'));
            modal.show();
        }

        // Confirmar eliminación
        document.getElementById('btnConfirmarEliminar').addEventListener('click', function() {
            if (actividadAEliminar) {
                mostrarSpinner(true);
                
                // Crear formulario para envío POST
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '../controllers/eliminar_actividad.php';
                
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'id_actividad';
                input.value = actividadAEliminar;
                
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        });

        // Filtros de actividades
        document.querySelectorAll('[data-filter]').forEach(btn => {
            btn.addEventListener('click', function() {
                // Actualizar botones activos
                document.querySelectorAll('[data-filter]').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                const filtro = this.dataset.filter;
                const actividades = document.querySelectorAll('.actividad-item');
                
                actividades.forEach(item => {
                    const estado = item.dataset.estado;
                    let mostrar = false;
                    
                    switch(filtro) {
                        case 'todas':
                            mostrar = true;
                            break;
                        case 'proximas':
                            mostrar = estado === 'proxima';
                            break;
                        case 'vencidas':
                            mostrar = estado === 'vencida';
                            break;
                    }
                    
                    if (mostrar) {
                        item.style.display = 'block';
                        item.style.animation = 'fadeIn 0.3s ease';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });

        // Función para mostrar spinner
        function mostrarSpinner(mostrar) {
            const spinner = document.querySelector('.loading-spinner');
            if (mostrar) {
                spinner.style.display = 'block';
            } else {
                spinner.style.display = 'none';
            }
        }

        // Auto-dismissal de alertas
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);

        // Actualizar fechas en tiempo real cada 5 minutos
        setInterval(function() {
            // Solo recargar si la página ha estado inactiva por un tiempo
            if (document.visibilityState === 'visible') {
                location.reload();
            }
        }, 300000); // 5 minutos

        // Animaciones CSS
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(10px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            @keyframes slideIn {
                from { transform: translateX(-20px); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            
            .actividad-item {
                animation: slideIn 0.3s ease;
            }
        `;
        document.head.appendChild(style);

        // Inicialización
        document.addEventListener('DOMContentLoaded', function() {
            // Ocultar spinner al cargar
            mostrarSpinner(false);
            
            // Añadir eventos a los collapse
            document.querySelectorAll('.curso-collapse').forEach(header => {
                header.addEventListener('click', function() {
                    const icon = this.querySelector('.collapse-icon');
                    // El toggle se maneja automáticamente por Bootstrap
                });
            });
        });
    </script>
</body>
</html>