<?php include '../../includes/header.php'; ?>

<div class="container mt-4">
  <h2>Datos del Estudiante</h2>
  <ul class="list-group">
    <li class="list-group-item">Nombre: Juan Pérez</li>
    <li class="list-group-item">Correo: juan@gmail.com</li>
    <li class="list-group-item">Notas: 18</li>
  </ul>
</div>

<?php include '../../includes/footer.php'; ?>
