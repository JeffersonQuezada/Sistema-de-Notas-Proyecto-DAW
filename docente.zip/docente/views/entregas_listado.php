<?php include '../../includes/header.php'; ?>

<div class="container mt-4">
  <h2>Listado de Entregas</h2>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Estudiante</th>
        <th>Archivo</th>
        <th>Fecha</th>
        <th>Comentario</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Juan Pérez</td>
        <td><a href="#">ver archivo</a></td>
        <td>2025-06-05</td>
        <td>Bien hecho</td>
      </tr>
    </tbody>
  </table>
</div>

<?php include '../../includes/footer.php'; ?>
